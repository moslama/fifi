#ifndef CHECK_H
# define CHECK_H

#include <unistd.h>

#endif
